<?php
/**
* Logimetrix Techsolution Pvt. Ltd.
 * File Name   : ProjectManagementController.php
 * File Description  : Project Management Controller
 * Created By : Akanksha Singh
 * Created Date: 07 Feb 2023
 */
 
 use Zend\Http\Request;

class ProjectManagementController extends Zend_Controller_Action
{
	var $dbAdapter;
	
	public function init()
	{
		/* Initialize action controller here */
		$this->_flashMessenger  = $this->_helper->getHelper('FlashMessenger');
		$this->initView();
		$bootstrap        = $this->getInvokeArg('bootstrap');
		$aConfig        = $bootstrap->getOptions();
		$this->view->siteurl  = $aConfig['site']['image']['url'];
		$this->view->duration   = $aConfig['pending']['days']['duration'];
		$this->dbAdapter    = Zend_Db_Table::getDefaultAdapter(); 
		$auth                   = Zend_Auth::getInstance();
		$authStorage           = $auth->getStorage();
		$this->id              = $authStorage->read()->id;
		$this->role            = $authStorage->read()->role;
		$this->role_type   		= $authStorage->read()->role_type;
		$user = new Application_Model_User(); 
		$this->view->getModule = $getModule = $user->getModule($this->role_type);
	}
	/*** indexAction() method is used to get task data */
	public function indexAction()
	{
		try {
			$this->checklogin(); 
			$this->view->messages = $this->_flashMessenger->getMessages();
			$db =Zend_Db_Table::getDefaultAdapter(); 
			$dbAdapter = $this->dbAdapter;
			$auth = Zend_Auth::getInstance(); 
			$authStorage = $auth->getStorage();    
			$params = $this->getRequest()->getParams();     
			$user = new Application_Model_User(); 
			$this->view->role =		$this->role ;
			$this->view->role_type = $this->role_type;
			$poDetailsQuery = $this->dbAdapter->select()
    		->from('tbl_po_sites as ps', array('*'))
    		->joinLeft('tbl_states as ts','ts.id = ps.state_id',array("state_name"))
    		->joinLeft('tbl_client_master as cm','cm.id = ps.client_id',array("client_name"))
    		->joinLeft('tbl_deployment as td','ps.po_no = td.po AND ps.site_id = td.site_id',array("so_no","work_type","location"))
    		->joinLeft('tbl_po_details as pd','pd.po_no = ps.po_no',array("order_date","po_amount","status","is_deleted","id","rev"))
    		->where('pd.status=?',0)
    		->where('pd.is_deleted=?',0)
    		->order('pd.id desc');
		$this->view->poDetailsList = $poDetailsResult = $this->dbAdapter->fetchAll($poDetailsQuery);
		} catch(Exception $e){
			echo $e->getMessage();
			exit;
		}
	}
	
	public function projectManagementAction()
	{
		try {
			$this->checklogin(); 
			$this->view->messages = $this->_flashMessenger->getMessages();
			$db =Zend_Db_Table::getDefaultAdapter(); 
			$dbAdapter = $this->dbAdapter;
			$auth = Zend_Auth::getInstance(); 
			$authStorage = $auth->getStorage();    
			$params = $this->getRequest()->getParams();     
			$user = new Application_Model_User(); 
			$this->view->role =		$this->role ;
			$this->view->role_type = $this->role_type;
// 			$poDetailsQuery = $this->dbAdapter->select()
//     		->from('tbl_po_sites as ps', array('*'))
//     		->joinLeft('tbl_states as ts','ts.id = ps.state_id',array("state_name"))
//     		->joinLeft('tbl_client_master as cm','cm.id = ps.client_id',array("client_name"))
//     		->joinLeft('tbl_deployment as td','ps.po_no = td.po AND ps.site_id = td.site_id',array("so_no","work_type","location"))
//     		->joinLeft('tbl_po_details as pd','pd.po_no = ps.po_no',array("order_date","po_amount","status","is_deleted","id","rev"))
//     		->where('pd.status=?',0)
//     		->where('pd.is_deleted=?',0)
//     		->order('pd.id desc');
// 		$this->view->poDetailsList = $poDetailsResult = $this->dbAdapter->fetchAll($poDetailsQuery);
		} catch(Exception $e){
			echo $e->getMessage();
			exit;
		}
	}
	
		public function checklogin(){   
		$auth       = Zend_Auth::getInstance(); 
		$errorMessage   = ""; 
		/*************** check user identity ************/
		if(!$auth->hasIdentity()){
			$this->_redirect('/admin/index');  
		}   
	} 

}