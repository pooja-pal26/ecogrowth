<?php

    /**

    * Logimetrix Techsolutions Pvt. Ltd.

    * File Name   : AuthlogoutController.php

    * File Description  : AuthlogoutController

    * Created By : Ajay Kumar

    * Created Date: 27 DEC 2016

    */
    
    use Zend\Http\Request;



    class AuthLogoutController extends Zend_Controller_Action{

        var $dbAdapter;	

        public function init(){

            /* Initialize action controller here */

            $this->dbAdapter    = Zend_Db_Table::getDefaultAdapter(); 

            $this->currdate     = date("Y-m-d H:i:s");//$date->toString('Y-m-d H:m:s');

        }	

            /**

        * index() method is used to admin login

        * @param Username and password

            * @return True 

        */



            public function indexAction(){
                

                    // Action Body

            }



            /**** logout **********/

            public function logoutAction(){
                $request = new Request();
                 $cookie= $request->getRequest()->getCookie();
                //print_r($cookie);
                if ($cookie->offsetExists('PHPSESSID')) {
                    $new_cookie= new SetCookie('PHPSESSID', '');//<---empty value and the same 'name'
                    $new_cookie->setExpires(-(time() + 365 * 60 * 60 * 24));
                }
                $this->_redirect('/index');
                
                $db             = $this->dbAdapter;

                $auth           = Zend_Auth::getInstance();

                $authStorage    = $auth->getStorage();

                $WebLoginID     = $authStorage->read()->WebLoginID;

                $role           = $authStorage->read()->role; 

                $admin          = new Application_Model_Admin();

                $logout_details = $admin->getUserLoginDetailByWebLoginCode($WebLoginID);



            // logout time date update in user_login_detail

                if($logout_details['WebLoginID'] !=""){

                    $logout_time = $this->currdate;

                    $users->updateUserLogoutDetailsByLoginID($WebLoginID,$logout_time);			

                }	

                
               
                
                

                $storage        = new Zend_Auth_Storage_Session();
                $storage->clear();

                if($role == "super_admin"){

                    $this->_redirect('/admin');

                }

                else{

                    $this->_redirect('/index');

                }

            }



            /**** check login **********/

            public function checklogin(){

                $auth           = Zend_Auth::getInstance();		

                $errorMessage   = ""; 

                /*************** check user identity ************/

                if(!$auth->hasIdentity()){  

                   $this->_redirect('/admin/index');  

               } 

           }	

       }

       ?>

