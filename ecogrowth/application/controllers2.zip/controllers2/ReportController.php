<?php
/**
* Logimetrix Techsolution Pvt. Ltd.
 * File Name   : ReportController.php
 * File Description  : Report Controller
 * Created By : Ajay Kumar
 * Created Date: 07 July 2017
 */

class ReportController extends Zend_Controller_Action
{
	var $dbAdapter;

	public function init()
	{
		$this->checklogin();
		/* Initialize action controller here */
		$this->_flashMessenger  = $this->_helper->getHelper('FlashMessenger');
		$this->initView();
		$bootstrap        = $this->getInvokeArg('bootstrap');
		$aConfig        = $bootstrap->getOptions();
		$this->view->siteurl  = $aConfig['site']['image']['url'];
		$this->dbAdapter    = Zend_Db_Table::getDefaultAdapter(); 
		$auth                   = Zend_Auth::getInstance();
		$authStorage           = $auth->getStorage();
		$this->id              = $authStorage->read()->id;
		$this->role            = $authStorage->read()->role;
		$this->role_type        = $authStorage->read()->role_type;
        $user = new Application_Model_User(); 
        $this->view->getModule = $getModule = $user->getModule($this->role_type);
	}

  // public function indexAction()
  // {
  //   echo "Hello world!";exit;
  // }
	/*** taskReportAction() method is used to get task data */
	public function taskReportAction()
	{
		$this->checklogin();
        //echo "helsf";exit;
		$this->db              = Zend_Db_Table::getDefaultAdapter();
        //$this->view->messages  = $this->_flashMessenger->getMessages();  
		$this->view->params = $params = $this->getRequest()->getParams(); 
		$query = "select  s.*, u.name as allocate_user, sup.name as supervisor, v.vendor_name as vendor, st.name as status_name  from  tbl_site_allocation as s 
		left join tbl_user as u on (s.allocate_userid = u.id)
		left join tbl_user as sup on (s.supervisor_id = sup.id)
		left join tbl_vendor as v on (s.allocate_userid = v.id)
		left join tbl_site_status as st on (s.status = st.status)
		where 1";
		$allocate_site_list = $this->dbAdapter->fetchAll($query);
         // echo "<pre>";
         //    print_r($params);exit;

		if($this->getRequest()->isPost())
		{
			function dateConverter($var)
			{
				$date = explode('-', $var);
				$final_date = $date['2'].'-'.$date['1'].'-'.$date['0'];
				return $final_date;
			}

			if(!$params['date_fr'] && $params['date_tt']){

				$cond  .="and date(s.created) = '".dateConverter($params['date_tt'])."'";

			}

			if($params['date_fr'] && !$params['date_tt']){

				$cond  .="and date(s.created) = '".dateConverter($params['date_fr'])."'";
			}

			if($params['date_fr'] && $params['date_tt']){

				$cond  .="and date(s.created) between '".dateConverter($params['date_fr'])."' and '".dateConverter($params['date_tt'])."'";
			}
			$query1 = "select  s.*, u.name as allocate_user, sup.name as supervisor, v.vendor_name as vendor, st.name as status_name  from  tbl_site_allocation as s 
			left join tbl_user as u on (s.allocate_userid = u.id)
			left join tbl_user as sup on (s.supervisor_id = sup.id)
			left join tbl_vendor as v on (s.allocate_userid = v.id)
			left join tbl_site_status as st on (s.status = st.status)
			where 1 $cond ";
			$allocate_site_list = $this->dbAdapter->fetchAll($query1);
		}

		if($params['type'] == 'Generate'){

			$data = array(array('Sr. No.'=> "", 'PO'=> "", 'Site Id'=> "" , 'Assigned Date'=> "" ,'Status'=> "" , 'Zone '=> "" , 'Cluster'=> "" , 'Technician Name'=> "", 'Technician Mobile No.'=> "", 'Allocated User'=> ""));
			$i = 2; 
			foreach ($allocate_site_list as $rs) { 
				if($rs['allocate_user']){ $allocate_user= $rs['allocate_user']; }else { $allocate_user= 'N/A';}
				if($rs['supervisor']){ $supervisor= $rs['supervisor']; }else { $supervisor= 'N/A';}
				if($rs['vendor']){ $vendor= $rs['vendor']; }else { $vendor= 'N/A';}
				if($rs['status_name']){ $status_name= $rs['status_name']; }else { $status_name= 'N/A';}
				$row = array();
				$row[] = stripslashes($i-1);
				$row[] = stripslashes($rs['po_no']);
				$row[] = stripslashes($rs["site_id"]);
				$row[] = stripslashes($rs["created"]);
				$row[] = stripslashes($rs["status_name"]);
				$row[] = stripslashes($rs["zone"]);
				$row[] = stripslashes($rs['cluster']);
				$row[] = stripslashes($rs["tech_name"]);
				$row[] = stripslashes($rs["tech_mobile"]);                      
				$row[] = stripslashes($allocate_user);                                                        
				$data[] = $row;
				$i++;
			}
			function filterData(&$str){
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}

                    // file name for download
			$fileName = "task-report.xls"; 

                    // headers for download
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");

			$flag = false;
			foreach($data as $row) {
				if(!$flag) {
                            // display column names as first row
					echo implode("\t", array_keys($row));
					$flag = true;
				}
                        // filter data
				array_walk($row, 'filterData');
				echo implode("\t", array_values($row)) . "\n";
			}
			exit;
		}           

		$this->view->totalnum  = $params['page'];
		$page=$this->_getParam('page',1);
		$paginator = Zend_Paginator::factory($allocate_site_list);      
         $paginator->setCurrentPageNumber($this->getRequest()->getParam('page')); // page number
         $paginator->setItemCountPerPage(10); // number of items to show per page
         $this->view->paginator = $paginator;
         $this->view->totalrec = $paginator->getTotalItemCount(); 
         
       }
       public function checkAttendance($emp_id, $date){ 
        $this->checklogin();
        $sql = "select * from tbl_staff_office_attendance where   user_id = '".$emp_id."' and start_date LIKE '%".$date."%'";
        $result = $this->dbAdapter->fetchRow($sql);
        if($result){
         return true;
       }else{
         return false;
       }
     }
     public function checkSunday($date){
     	$this->checklogin(); 
     	$day = date("D", strtotime($date));
     	if($day == 'Sun'){
     		return true;
     	}else{
     		return false;
     	}
     }

     public function materialStockReportAction(){
     	try {
     		$this->checklogin();
     		$this->view->role_id = $this->id;
     		$params = $this->getRequest()->getParams();
     		$materialStockQuery = "SELECT tbl_inventory.*,tbl_product_type.product_type_name AS product_type,tbl_products.product_name FROM `tbl_inventory`
     		LEFT JOIN tbl_product_type on (tbl_inventory.product_type_id = tbl_product_type.id)
     		LEFT JOIN tbl_products on (tbl_inventory.product_id = tbl_products.id) ORDER BY tbl_inventory.created_at DESC";
     		$this->view->materialStocklist = $materialStocklist = $this->dbAdapter->fetchAll($materialStockQuery);
     	}
     	catch(Exception $e){
     		echo $e->getMessage();
     		exit;
     	}
     }


     public function materialStockInReportAction(){
     	try{
     		$this->checklogin();
     		$this->view->role_id = $this->id;
     		$params = $this->getRequest()->getParams();
     		$stockinsql = "SELECT tbl_stock_in.*, tbl_suppliers.name AS supplier_name, tbl_user.name AS receiver_name FROM tbl_stock_in 
     		LEFT JOIN tbl_suppliers ON (tbl_suppliers.id = tbl_stock_in.supplier_id)
     		LEFT JOIN tbl_user ON (tbl_user.id = tbl_stock_in.recieved_by)
     		ORDER BY tbl_stock_in.stock_in_date DESC";
     		$this->view->stockinlist = $stockinlist = $this->dbAdapter->fetchAll($stockinsql);
     	}
     	catch(Exception $e){
     		echo $e->getMessage();
     		exit;
     	}
     }


     public function viewStockinAction(){
     	try{
     		$params = $this->getRequest()->getParams();
        
     		$sql_unit = "SELECT tbl_stock_in_details.*,tbl_stock_in.stock_in_date,(tbl_product_type.product_type_name)AS product_type,tbl_products.product_name ,tbl_material_brand.brand_name as brand 
        FROM `tbl_stock_in_details`
        LEFT JOIN tbl_stock_in ON (tbl_stock_in_details.stock_in_id = tbl_stock_in.id)
        LEFT JOIN tbl_product_type ON (tbl_stock_in_details.product_type =tbl_product_type.id)
        LEFT JOIN tbl_material_brand ON (tbl_stock_in_details.brand_name = tbl_material_brand.id)
        LEFT JOIN tbl_products ON (tbl_stock_in_details.product_name = tbl_products.id) WHERE stock_in_id = '".$params['id']."'"; 
        
        $this->view->stockindetail= $stockindetail= $this->dbAdapter->fetchAll($sql_unit);

        // echo '<pre>';
        // print_r($sql_unit);
        // exit();
        $this->_helper->layout()->disableLayout();
      } catch(Exception $e){
       echo $e->getMessage();
       exit;
     }

   }
   public function materialStockOutReportAction()
   {
    try {
     $this->checklogin();
     $this->view->role_id = $this->id;
     $params = $this->getRequest()->getParams();
     $stockoutsql = "SELECT * FROM tbl_stock_out ORDER BY stock_out_date DESC";
     $this->view->stockoutlist = $stockoutlist = $this->dbAdapter->fetchAll($stockoutsql);
   }
   catch(Exception $e){
     echo $e->getMessage();
     exit;
   }
 }

 public function viewStockOutAction(){
  try{
   $params = $this->getRequest()->getParams();

   $sql_unit = "SELECT tbl_stock_out_details.quantity,tbl_stock_out_details.unit,(tbl_product_type.product_type_name) AS product_type,tbl_products.product_name,(tbl_material_brand.brand_name) AS brand FROM `tbl_stock_out_details`
   LEFT join tbl_product_type on (tbl_stock_out_details.product_type = tbl_product_type.id)
   LEFT join tbl_products on (tbl_stock_out_details.product_name = tbl_products.id)
   LEFT join tbl_material_brand on (tbl_stock_out_details.brand = tbl_material_brand.id) WHERE stock_out_id = '".$params['id']."'";
   $this->view->stockoutdetail =$stockoutdetail = $this->dbAdapter->fetchAll($sql_unit);
   $this->_helper->layout()->disableLayout();
 } catch(Exception $e){
   echo $e->getMessage();
   exit;
 }

}



public function attendanceReportAction(){

  $this->checklogin(); 
  $params                = $this->view->params = $this->getRequest()->getParams(); 
  $this->db              = Zend_Db_Table::getDefaultAdapter();
  $roles                 = new Application_Model_User();
  $this->view->attendance_report = $attendance_report  = $roles->getAttendanceRecord();
  if($this->getRequest()->isPost())
  {
   function dateConverter($var)
   {
    $date = explode('-', $var);
    $final_date = $date['2'].'-'.$date['1'].'-'.$date['0'];
    return $final_date;
  }         
  $condition .="and date(created) BETWEEN '".dateConverter($params['date_fr'])."'  AND '".dateConverter($params['date_tt'])."'";
  $query1 = "select * from tbl_staff_attendance where 1 $condition ";
  $attendance_report = $this->db->fetchAll($query1);
}

if($params['type'] == 'Generate'){

 $data = array(array('Sr. No.'=> "", 'User'=> "", 'User Type'=> "" , 'Contact No.'=> "" ,'Start Day Datetime'=> "" , 'Start Day Latitude '=> "" , 'Start Day Longitude '=> "", 'End Day Datetime'=> "" , 'End Day Latitude'=> "", 'End Day Longitude'=> "", 'End Day Longitude'=> "",'Created'=> "",'Working Hour'=> ""));
 $i = 2; 
 foreach ($attendance_report as $rs) { 
  $diff = strtotime($rs['end_day_datetime']) - strtotime($rs['start_day_datetime']);
                          //$diff_in_hrs = $diff/3600;
  $hours   = floor(($diff - ($days * 86400)) / 3600);
  $minutes = floor(($diff - ($days * 86400) - ($hours * 3600))/60);

  $row = array();
  $row[] = stripslashes($i-1);
  $row[] = stripslashes($rs['user_id']);
  $row[] = stripslashes($rs["user_type"]);
  $row[] = stripslashes($rs["contact_no"]);
  $row[] = stripslashes($rs["start_day_datetime"]);
  $row[] = stripslashes($rs["start_day_latitude"]);
  $row[] = stripslashes($rs['start_day_longitude']);
  $row[] = stripslashes($rs["end_day_datetime"]);
  $row[] = stripslashes($rs["end_day_latitude"]);
  $row[] = stripslashes($rs["end_day_longitude"]);                        
  $row[] = stripslashes($rs["created"]);
  $row[] = stripslashes($hours.'h '.$minutes.'m ');                                                          
  $data[] = $row;
  $i++;
}
function filterData(&$str){
  $str = preg_replace("/\t/", "\\t", $str);
  $str = preg_replace("/\r?\n/", "\\n", $str);
  if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
}

                    // file name for download
$fileName = "attendance-report.xls"; 
                    // headers for download
header("Content-Disposition: attachment; filename=\"$fileName\"");
header("Content-Type: application/vnd.ms-excel");

$flag = false;
foreach($data as $row) {
  if(!$flag) {
                            // display column names as first row
   echo implode("\t", array_keys($row));
   $flag = true;
 }
                        // filter data
 array_walk($row, 'filterData');
 echo implode("\t", array_values($row)) . "\n";
}
exit;
}           
$page=$this->_getParam('page',1);
$paginator = Zend_Paginator::factory($attendance_report);      
          $paginator->setCurrentPageNumber($this->getRequest()->getParam('page')); // page number
          $paginator->setItemCountPerPage(10); // number of items to show per page
          $this->view->paginator = $paginator;
          $this->view->perPage = 10;
          $this->view->totalrec = $paginator->getTotalItemCount();
        }
        public function attendenceListAction()
        {
         $this->checklogin();
         $params                = $this->view->params = $this->getRequest()->getParams();
         $this->db              = Zend_Db_Table::getDefaultAdapter();
         $roles                 = new Application_Model_User();
         $attendance_report  = $roles->searchAttendanceRecord($params['date_from'],$params['date_to']);
         $this->view->totalnum   = $params['page'];
         $page=$this->_getParam('page',1);
         $paginator = Zend_Paginator::factory($attendance_report);      
          $paginator->setCurrentPageNumber($this->getRequest()->getParam('page')); // page number
          $paginator->setItemCountPerPage(10); // number of items to show per page
          $this->view->paginator = $paginator;
          $this->view->perPage = 10;
          $this->view->totalrec = $paginator->getTotalItemCount();  
        }

        function dateConverter($var)
        {
         $date = explode('/', $var);
         $final_date = $date['2'].'-'.$date['1'].'-'.$date['0'];
         return $final_date;
       }

       public function siteWiseProfitLossAction()
       {
        try {
          $this->checklogin();
          $this->view->role_id = $this->id;
          $params = $this->getRequest()->getParams();
          
          // DEMO MODE: Static data (no DB dependency)
          $demoMode = true;
          if ($demoMode) {
            $this->view->from_date = isset($params['from_date']) ? $params['from_date'] : '';
            $this->view->to_date = isset($params['to_date']) ? $params['to_date'] : '';

            $sites = array(
              array('po_no' => 'PO-1001', 'site_id' => 'VS-001',  'site_name' => 'Veer Savarkar Marg', 'order_date' => '2021-09-10'),
              array('po_no' => 'PO-1002', 'site_id' => 'PTA-001', 'site_name' => 'Patna Site',          'order_date' => '2022-05-06')
            );

            $staticInvoices = array(
              array('invoice_no' => 'INV-001', 'invoice_date' => '2021-09-25', 'invoice_value' => 2950.00, 'invoice_remark' => 'Site Survey', 'taxable_value' => 2500.00, 'gst_amount' => 450.00),
              array('invoice_no' => 'INV-002', 'invoice_date' => '2021-10-07', 'invoice_value' => 95330.97, 'invoice_remark' => 'Civil', 'taxable_value' => 81297.43, 'gst_amount' => 14633.54),
              array('invoice_no' => 'INV-003', 'invoice_date' => '2021-10-22', 'invoice_value' => 25035.47, 'invoice_remark' => 'Electrical', 'taxable_value' => 21216.50, 'gst_amount' => 3818.97),
              array('invoice_no' => 'INV-004', 'invoice_date' => '2021-11-23', 'invoice_value' => 1180.00, 'invoice_remark' => 'PPC Foundation', 'taxable_value' => 1000.00, 'gst_amount' => 180.00),
              array('invoice_no' => 'INV-005', 'invoice_date' => '2021-11-23', 'invoice_value' => 1770.00, 'invoice_remark' => 'Site Cleaning', 'taxable_value' => 1500.00, 'gst_amount' => 270.00),
              array('invoice_no' => 'INV-006', 'invoice_date' => '2021-12-04', 'invoice_value' => 100217.08, 'invoice_remark' => 'Civil, Electrical & PMC Transport', 'taxable_value' => 84929.73, 'gst_amount' => 15827.35),
              array('invoice_no' => 'INV-007', 'invoice_date' => '2021-12-04', 'invoice_value' => 2360.00, 'invoice_remark' => 'Extra Transport', 'taxable_value' => 2000.00, 'gst_amount' => 360.00),
              array('invoice_no' => 'INV-008', 'invoice_date' => '2022-04-25', 'invoice_value' => 12095.00, 'invoice_remark' => 'Material Handling', 'taxable_value' => 10250.00, 'gst_amount' => 1845.00)
            );

            $staticExpenses = array(
              array('id' => 1,  'amount' => 3000.00,  'transfer_date' => '2021-09-10', 'remark' => 'Rahul for Steel Team', 'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 2,  'amount' => 4250.00,  'transfer_date' => '2021-09-13', 'remark' => 'Rahul for Chipping & Welding',         'nature_of_work' => 'Fabrication',         'allocation_type' => 'Cash'),
              array('id' => 3,  'amount' => 30000.00, 'transfer_date' => '2021-09-15', 'remark' => 'Sai Nath for Steel Advance',          'nature_of_work' => 'Material Advance',    'allocation_type' => 'Cash'),
              array('id' => 4,  'amount' => 10700.00, 'transfer_date' => '2021-09-16', 'remark' => 'Rahul for Rs. 8200/- for Gitti & Rs. 2500/- for Expenses', 'nature_of_work' => 'Material + Misc', 'allocation_type' => 'Cash'),
              array('id' => 5,  'amount' => 39490.00, 'transfer_date' => '2021-09-21', 'remark' => 'Sai Nath for Steel Final',            'nature_of_work' => 'Material',            'allocation_type' => 'Cash'),
              array('id' => 6,  'amount' => 14000.00, 'transfer_date' => '2021-09-21', 'remark' => 'Rahul for 12K for Steel Team & 2K for Expenses', 'nature_of_work' => 'Labour + Misc', 'allocation_type' => 'Cash'),
              array('id' => 7,  'amount' => 10000.00, 'transfer_date' => '2021-09-22', 'remark' => 'Rahul for Steel Team',               'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 8,  'amount' => 3000.00,  'transfer_date' => '2021-09-24', 'remark' => 'Rahul for Hydra A - Class',          'nature_of_work' => 'Transport',            'allocation_type' => 'Cash'),
              array('id' => 9,  'amount' => 5400.00,  'transfer_date' => '2021-09-24', 'remark' => 'Rahul for Sand',                      'nature_of_work' => 'Material',            'allocation_type' => 'Cash'),
              array('id' => 10, 'amount' => 7500.00,  'transfer_date' => '2021-09-25', 'remark' => 'Rahul for Expenses',                  'nature_of_work' => 'Misc',                 'allocation_type' => 'Cash'),
              array('id' => 11, 'amount' => 15347.00, 'transfer_date' => '2021-09-25', 'remark' => 'Singh Traders for 49 Bag Cement',     'nature_of_work' => 'Material',             'allocation_type' => 'Cash'),
              array('id' => 12, 'amount' => 10000.00, 'transfer_date' => '2021-09-26', 'remark' => 'Rahul for Expenses',                  'nature_of_work' => 'Misc',                 'allocation_type' => 'Cash'),
              array('id' => 13, 'amount' => 5000.00,  'transfer_date' => '2021-09-28', 'remark' => 'Rahul for Shuttering',               'nature_of_work' => 'Shuttering',           'allocation_type' => 'Cash'),
              array('id' => 14, 'amount' => 25954.00, 'transfer_date' => '2021-09-30', 'remark' => 'D.K. Sales for Electrical Material', 'nature_of_work' => 'Electrical Material',  'allocation_type' => 'Cash'),
              array('id' => 15, 'amount' => 6500.00,  'transfer_date' => '2021-09-30', 'remark' => 'Rahul for A - Class Transport',     'nature_of_work' => 'Transport',            'allocation_type' => 'Cash'),
              array('id' => 16, 'amount' => 13000.00, 'transfer_date' => '2021-10-09', 'remark' => 'Rishabh for Electrical Team',        'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 17, 'amount' => 6357.00,  'transfer_date' => '2021-10-11', 'remark' => 'D.K. Sales for GI Strip',            'nature_of_work' => 'Material',             'allocation_type' => 'Cash'),
              array('id' => 18, 'amount' => 11450.00, 'transfer_date' => '2021-10-14', 'remark' => 'Rahul for Chamber Painting',         'nature_of_work' => 'Painting',             'allocation_type' => 'Cash'),
              array('id' => 19, 'amount' => 1000.00,  'transfer_date' => '',           'remark' => 'Rishabh Salary @ 5%',               'nature_of_work' => 'Salary',               'allocation_type' => 'Cash'),
              array('id' => 20, 'amount' => 3200.00,  'transfer_date' => '',           'remark' => 'Office Rent & Other Exp. Approx @ 5%', 'nature_of_work' => 'Overheads',         'allocation_type' => 'Cash')
            );

            // Patna Site - static demo data
            $patnaInvoices = array(
              array('invoice_no' => 'PINV-001', 'invoice_date' => '2022-05-07', 'invoice_value' => 341098.98, 'invoice_remark' => 'Civil Tower Foundation', 'taxable_value' => 289066.93, 'gst_amount' => 52032.05),
              array('invoice_no' => 'PINV-002', 'invoice_date' => '2022-05-07', 'invoice_value' =>   2950.00, 'invoice_remark' => 'Site Survey',          'taxable_value' =>   2500.00, 'gst_amount' =>   450.00),
              array('invoice_no' => 'PINV-003', 'invoice_date' => null,        'invoice_value' =>  85354.12, 'invoice_remark' => 'Electrical + PMC + Transportation (Expected)_Invoice Pending', 'taxable_value' =>  72334.00, 'gst_amount' => 13020.12),
              array('invoice_no' => 'PINV-004', 'invoice_date' => null,        'invoice_value' =>  42480.00, 'invoice_remark' => 'Amendment',              'taxable_value' =>  36000.00, 'gst_amount' =>  6480.00),
              array('invoice_no' => 'PINV-005', 'invoice_date' => null,        'invoice_value' =>    944.00, 'invoice_remark' => 'Site Cleaning',          'taxable_value' =>    800.00, 'gst_amount' =>   144.00),
              array('invoice_no' => 'PINV-006', 'invoice_date' => null,        'invoice_value' =>   7080.00, 'invoice_remark' => 'Extra Transport (Expected_Invoice Pending)', 'taxable_value' =>   6000.00, 'gst_amount' =>  1080.00),
              array('invoice_no' => 'PINV-007', 'invoice_date' => null,        'invoice_value' =>   3186.00, 'invoice_remark' => 'Material Handling (Expected_Invoice Pending)', 'taxable_value' =>   2700.00, 'gst_amount' =>   486.00)
            );
            $patnaExpenses = array(
              array('id' => 1,  'amount' =>   5000.00,  'transfer_date' => '2022-04-02', 'remark' => 'Rahul for Steel Team',                 'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 2,  'amount' =>  13650.00,  'transfer_date' => '2022-04-04', 'remark' => 'JCB',                                   'nature_of_work' => 'Machine',              'allocation_type' => 'Cash'),
              array('id' => 3,  'amount' => 150000.00,  'transfer_date' => '2022-04-05', 'remark' => 'Steel Purchase',                        'nature_of_work' => 'Material',             'allocation_type' => 'Cash'),
              array('id' => 4,  'amount' =>  63300.00,  'transfer_date' => '2022-04-06', 'remark' => 'Gitti Sand (Aggregate)',                'nature_of_work' => 'Material',             'allocation_type' => 'Cash'),
              array('id' => 5,  'amount' =>  23240.00,  'transfer_date' => '2022-04-08', 'remark' => 'Steel Team + Cement Purchase',         'nature_of_work' => 'Material + Labour',    'allocation_type' => 'Cash'),
              array('id' => 6,  'amount' =>  50832.00,  'transfer_date' => '2022-04-08', 'remark' => 'Steel Purchase + Cement Purchase',     'nature_of_work' => 'Material',             'allocation_type' => 'Cash'),
              array('id' => 7,  'amount' =>   8896.00,  'transfer_date' => '2022-04-09', 'remark' => 'Generator',                            'nature_of_work' => 'Hire',                 'allocation_type' => 'Cash'),
              array('id' => 8,  'amount' =>  17500.00,  'transfer_date' => '2022-04-10', 'remark' => 'Steel Team',                           'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 9,  'amount' =>  38110.00,  'transfer_date' => '2022-04-11', 'remark' => 'Steel Team',                           'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 10, 'amount' =>  25196.00,  'transfer_date' => '2022-04-19', 'remark' => 'Electrical Material',                  'nature_of_work' => 'Material',             'allocation_type' => 'Cash'),
              array('id' => 11, 'amount' =>  15000.00,  'transfer_date' => '2022-04-24', 'remark' => 'A Class Transport',                    'nature_of_work' => 'Transport',            'allocation_type' => 'Cash'),
              array('id' => 12, 'amount' =>   8430.00,  'transfer_date' => '2022-04-26', 'remark' => 'Steel Team',                           'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 13, 'amount' =>  21100.00,  'transfer_date' => '2022-04-26', 'remark' => 'Electrical Team',                      'nature_of_work' => 'Labour',               'allocation_type' => 'Cash'),
              array('id' => 14, 'amount' =>   9900.00,  'transfer_date' => '2022-04-29', 'remark' => 'Repairing and Finishing Work',         'nature_of_work' => 'Work',                 'allocation_type' => 'Cash'),
              array('id' => 15, 'amount' =>   1000.00,  'transfer_date' => null,        'remark' => 'Rishabh Salary @ 5%',                  'nature_of_work' => 'Salary',               'allocation_type' => 'Cash')
            );

            $siteWiseData = array();
            $overall_totals = array('total_invoice_amount' => 0, 'total_expense' => 0, 'total_profit_loss' => 0);

            // Apply filter if specific site is selected
            $filteredSites = $sites;
            if (!empty($params['site_id'])) {
              $filteredSites = array_values(array_filter($sites, function($s) use ($params){ return $s['site_id'] === $params['site_id']; }));
              if (empty($filteredSites)) { $filteredSites = $sites; }
            }

            foreach ($filteredSites as $site) {
              $datasetInvoices = ($site['site_id'] === 'PTA-001') ? $patnaInvoices : $staticInvoices;
              $datasetExpenses = ($site['site_id'] === 'PTA-001') ? $patnaExpenses : $staticExpenses;

              $total_taxable_value = 0; $total_gst = 0; $total_invoice_amount = 0; $total_expense = 0;
              foreach ($datasetInvoices as $inv) {
                $total_taxable_value += (float)$inv['taxable_value'];
                $total_gst += (float)$inv['gst_amount'];
                $total_invoice_amount += (float)$inv['invoice_value'];
              }
              foreach ($datasetExpenses as $exp) { $total_expense += (float)$exp['amount']; }
              $profit_loss = $total_invoice_amount - $total_expense;
              $profit_loss_percentage = $total_invoice_amount > 0 ? ($profit_loss / $total_invoice_amount) * 100 : 0;

              $siteWiseData[] = array(
                'site_info' => $site,
                'invoices' => $datasetInvoices,
                'expenses' => $datasetExpenses,
                'totals' => array(
                  'total_taxable_value' => $total_taxable_value,
                  'total_gst' => $total_gst,
                  'total_invoice_amount' => $total_invoice_amount,
                  'total_expense' => $total_expense,
                  'profit_loss' => $profit_loss,
                  'profit_loss_percentage' => $profit_loss_percentage
                )
              );

              $overall_totals['total_invoice_amount'] += $total_invoice_amount;
              $overall_totals['total_expense'] += $total_expense;
              $overall_totals['total_profit_loss'] += $profit_loss;
            }

            $this->view->siteWiseData = $siteWiseData;
            $this->view->overallTotals = $overall_totals;
            $this->view->params = $params;
            $this->view->allSites = array(
              array('site_id' => 'VS-001',  'po_no' => 'PO-1001', 'site_name' => 'Veer Savarkar Marg'),
              array('site_id' => 'PTA-001', 'po_no' => 'PO-1002', 'site_name' => 'Patna Site')
            );

            return; // do not run DB path
          }

          // Get site filter if provided
          $site_id_filter = isset($params['site_id']) ? $params['site_id'] : '';
          $po_no_filter = isset($params['po_no']) ? $params['po_no'] : '';
          $from_date = isset($params['from_date']) ? $params['from_date'] : '';
          $to_date = isset($params['to_date']) ? $params['to_date'] : '';
          
          // Get all sites
          $sitesQuery = $this->dbAdapter->select()
            ->from('tbl_po_sites', array('po_no', 'site_id', 'site_name', 'order_date'))
            ->where('is_deleted = ?', 0);
          
          if ($site_id_filter) {
            $sitesQuery->where('site_id = ?', $site_id_filter);
          }
          if ($po_no_filter) {
            $sitesQuery->where('po_no = ?', $po_no_filter);
          }
          
          $sitesQuery->order('order_date DESC');
          $sites = $this->dbAdapter->fetchAll($sitesQuery);
          
          $siteWiseData = array();
          
          foreach ($sites as $site) {
            $site_id = $site['site_id'];
            $po_no = $site['po_no'];
            
            // Fetch Invoice Details for this site (guard optional columns)
            $hasColumn = function($tableName, $columnName) {
              try {
                $sql = "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '".$tableName."' AND COLUMN_NAME = '".$columnName."' LIMIT 1";
                $row = $this->dbAdapter->fetchRow($sql);
                return !empty($row);
              } catch(Exception $e) {
                return false;
              }
            };

            $invoiceColumns = array('invoice_no','invoice_date','invoice_value','invoice_remark');
            if ($hasColumn('tbl_punched_invoice_details','taxable_value')) { $invoiceColumns[] = 'taxable_value'; }
            if ($hasColumn('tbl_punched_invoice_details','gst_amount')) { $invoiceColumns[] = 'gst_amount'; }
            if ($hasColumn('tbl_punched_invoice_details','cgst_amount')) { $invoiceColumns[] = 'cgst_amount'; }
            if ($hasColumn('tbl_punched_invoice_details','sgst_amount')) { $invoiceColumns[] = 'sgst_amount'; }
            if ($hasColumn('tbl_punched_invoice_details','igst_amount')) { $invoiceColumns[] = 'igst_amount'; }

            $invoiceQuery = $this->dbAdapter->select()
              ->from('tbl_punched_invoice_details', $invoiceColumns)
              ->where('site_id = ?', $site_id)
              ->where('po_no = ?', $po_no)
              ->where('status = ?', 1);
            
            if ($from_date && $to_date) {
              // Convert date format from YYYY-MM-DD (form input) to YYYY-MM-DD (database format)
              $invoiceQuery->where("date(invoice_date) BETWEEN ? AND ?", array($from_date, $to_date));
            }
            
            $invoiceQuery->order('invoice_date ASC');
            $invoices = $this->dbAdapter->fetchAll($invoiceQuery);
            
            // Calculate invoice totals
            $total_taxable_value = 0;
            $total_gst = 0;
            $total_invoice_amount = 0;
            
            foreach ($invoices as $inv) {
              $taxable = isset($inv['taxable_value']) ? (float)$inv['taxable_value'] : 0;
              $gst = isset($inv['gst_amount']) ? (float)$inv['gst_amount'] : 0;
              if ($gst == 0) {
                $gst = (isset($inv['cgst_amount']) ? (float)$inv['cgst_amount'] : 0) + 
                       (isset($inv['sgst_amount']) ? (float)$inv['sgst_amount'] : 0) + 
                       (isset($inv['igst_amount']) ? (float)$inv['igst_amount'] : 0);
              }
              $invoice_amt = isset($inv['invoice_value']) ? (float)$inv['invoice_value'] : 0;
              
              if ($taxable == 0 && $invoice_amt > 0) {
                // Estimate taxable value if not available
                $taxable = $invoice_amt / 1.18; // Assuming 18% GST
                $gst = $invoice_amt - $taxable;
              }
              
              $total_taxable_value += $taxable;
              $total_gst += $gst;
              $total_invoice_amount += $invoice_amt;
            }
            
            // Fetch Expense Details for this site
            $expenseQuery = $this->dbAdapter->select()
              ->from('tbl_site_expense', array(
                'id',
                'amount',
                'transfer_date',
                'remark',
                'nature_of_work',
                'allocation_type'
              ))
              ->where('site_id = ?', $site_id)
              ->where('po_no = ?', $po_no)
              ->where('status = ?', 1);
            
            if ($from_date && $to_date) {
              // Convert date format from YYYY-MM-DD (form input) to YYYY-MM-DD (database format)
              $expenseQuery->where("date(transfer_date) BETWEEN ? AND ?", array($from_date, $to_date));
            }
            
            $expenseQuery->order('transfer_date ASC');
            $expenses = $this->dbAdapter->fetchAll($expenseQuery);
            
            // Calculate expense total
            $total_expense = 0;
            foreach ($expenses as $exp) {
              $total_expense += isset($exp['amount']) ? (float)$exp['amount'] : 0;
            }
            
            // Calculate Profit/Loss
            $profit_loss = $total_invoice_amount - $total_expense;
            $profit_loss_percentage = $total_invoice_amount > 0 ? ($profit_loss / $total_invoice_amount) * 100 : 0;
            
            $siteWiseData[] = array(
              'site_info' => $site,
              'invoices' => $invoices,
              'expenses' => $expenses,
              'totals' => array(
                'total_taxable_value' => $total_taxable_value,
                'total_gst' => $total_gst,
                'total_invoice_amount' => $total_invoice_amount,
                'total_expense' => $total_expense,
                'profit_loss' => $profit_loss,
                'profit_loss_percentage' => $profit_loss_percentage
              )
            );
          }
          
          // Calculate overall totals
          $overall_totals = array(
            'total_invoice_amount' => 0,
            'total_expense' => 0,
            'total_profit_loss' => 0
          );
          
          foreach ($siteWiseData as $data) {
            $overall_totals['total_invoice_amount'] += $data['totals']['total_invoice_amount'];
            $overall_totals['total_expense'] += $data['totals']['total_expense'];
            $overall_totals['total_profit_loss'] += $data['totals']['profit_loss'];
          }
          
          $this->view->siteWiseData = $siteWiseData;
          $this->view->overallTotals = $overall_totals;
          $this->view->params = $params;
          $this->view->from_date = $from_date;
          $this->view->to_date = $to_date;
          
          // Get all sites and PO numbers for filter dropdown
          $allSitesQuery = $this->dbAdapter->select()
            ->from('tbl_po_sites', array('site_id', 'po_no', 'site_name'))
            ->where('is_deleted = ?', 0)
            ->group(array('site_id', 'po_no'))
            ->order('site_id ASC');
          $this->view->allSites = $this->dbAdapter->fetchAll($allSitesQuery);
          
        } catch(Exception $e) {
          echo $e->getMessage();
          exit;
        }
       }

       public function checklogin(){   
         $auth           = Zend_Auth::getInstance(); 
         $errorMessage   = ""; 
         /*************** check user identity ************/
         if(!$auth->hasIdentity()){
          $this->_redirect('/admin/index');  
        }   
      } 
    }